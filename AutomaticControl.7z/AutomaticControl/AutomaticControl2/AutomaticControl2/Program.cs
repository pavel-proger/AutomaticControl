﻿/*
 * Created by SharpDevelop.
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Timers; 

namespace AutomaticControl2
{
	class Program
	{
		public static void Main(string[] args)
		{
			bool imputControl2; // пропуск на въезд автомобиля получен ( По аналогии с imputControl из вышестояшего кода )
			bool outputControl2; // пропуск на выезд автомобиля получен ( По аналогии с outputControl из вышестоящего кода и так далее )
			bool doorInControl2; // пропуск на вход посетителя получен
			bool doorOutControl2; // пропуск на выход посетителя получен
			bool gateOpen2; // команда на открытие ворот где true – открыть, а false – закрыть
			bool doorClose; // команда на закрытие двери для открытия ворот где true – закрыть, а false – не закрывать
			bool door1IsEmpty; // сигнализатор присутствия человека на входе, пока выходящий человек не пройдет через него дверь у ворот не закроется
			bool door2IsEmpty; // сигнализатор присутствия человека на выходе, пока входящий человек не пройдет через него дверь у ворот не закроется
			bool gateInCloseSign; // сигнализатор закрытия на въезд ворот, свидетельствующий о наличие выезжающего автомобиля и запрещающий въезд, где true это сигнал "close", а false это сигнал "open"
			bool gateOutCloseSign; // сигнализатор закрытия на выезд ворот, свидетельствующий о наличие въезжающего автомобиля и запрещающий выезд, где true это сигнал "close", а false это сигнал "open"
			bool doorCloseSign; // сигнализатор закрытия на вход и выход дверей, свидетельствующий о наличие автомобиля у ворот и запрещающий проход через двери, где true это сигнал "close", а false это сигнал "open"
			int gateControl2; // состояние пропускной системы
			
			
			
			switch ( gateControl2 ) 
				{
				case 0 :
				gateOpen2 = false;
				doorClose = false;
				gateInCloseSign = false;
				gateOutCloseSign = false;
				doorCloseSign = false;
				if (imputControl2 == true and outputControl2 == false)
				{
				gateControl2 = 1;
				}
				else if (imputControl2 == false and outputControl2 == true )
				{
				gateControl2 = 2;
				}
				else if (imputControl2 == true and outputControl2 == true )
				{
				gateControl2 = 3;
				}
				else if (imputControl2 == false and outputControl2 == false and ( doorInControl2 == true or doorOutControl2 == true ))
				{
				gateControl2 = 4;
				}
				break; 
				case 1:
				if ( doorInControl2 == true and door2IsEmpty == true)
				{
				doorClose = true;
				gateOpen2 = true;
				}
				else
				{
				doorClose = false;
				gateOpen2 = false;
				}
				if ( doorOutControl2 == true and door1IsEmpty == true)
				{
				doorClose = true;
				gateOpen2 = true;
				}
				else
				{
				doorClose = false;
				gateOpen2 = false;
				}
				gateInCloseSign = false;
				gateOutCloseSign = true;
				doorCloseSign = true;
				if (imputControl2 == false and outputControl2 == false and doorInControl2 == false and doorOutControl2 == false )
				{
				gateControl2 = 0;
				}
				else if (imputControl2 == false and outputControl2 == true )
				{
				gateControl2 = 2;
				}
				else if (imputControl2 == true and outputControl2 == true )
				{
				gateControl2 = 3;
				}
				else if (imputControl2 == false and outputControl2 == false and ( doorInControl2 == true or doorOutControl2 == true ))
				{
				gateControl2 = 4;
				}
				break;
				case 2:
				if ( doorInControl2 == true and door2IsEmpty == true)
				{
				doorClose = true;
				gateOpen2 = true;
				}
				else
				{
				doorClose = false;
				gateOpen2 = false;
				}
				if ( doorOutControl2 == true and door1IsEmpty == true)
				{
				doorClose = true;
				gateOpen2 = true;
				}
				else
				doorClose = false;
				gateOpen2 = false;
				gateInCloseSign = true;
				gateOutCloseSign = false;
				doorCloseSign = true;
				if (imputControl2 == true and outputControl2 == false)
				{
				gateControl2 = 1;
				}
				else if (imputControl2 == false and outputControl2 == false and doorInControl2 == false and doorOutControl2 == false )
				{
				gateControl2 = 0;
				}
				else if (imputControl2 == true and outputControl2 == true )
				{
				gateControl2 = 3;
				}
				else if (imputControl2 == false and outputControl2 == false and ( doorInControl2 == true or doorOutControl2 == true ))
				{
				gateControl2 = 4;
				}
				break;
				
				case 3:
				if ( doorInControl2 == true and door2IsEmpty == true)
				{
				doorClose = true;
				gateOpen2 = true;
				}
				else
				{
				doorClose = false;
				gateOpen2 = false;
				}
				if ( doorOutControl2 == true and door1IsEmpty == true)
				{
				doorClose = true;
				gateOpen2 = true;
				}
				else
				{
				doorClose = false;
				gateOpen2 = false;
				}
				Timer InTimer = new Timer() ;
				Timer OutTimer = new Timer() ;
				if ( imputControl2 == true )
				{
				InTimer.Enabled = true;
				InTimer.Elapsed += new ElapsedEventHandler( DisplayTimeEvent ) ;
				InTimer.Interval = 120000 ;
				}
				if ( outputControl2 == true )
				{
				OutTimer.Enabled = true;
				OutTimer.Elapsed += new ElapsedEventHandler( DisplayTimeEvent ) ;
				OutTimer.Interval = 120000 ;
				}
				if ( InTimer.Value > OutTimer.Value)
				{
				if ( doorInControl2 == true and doorOutControl2 == true)
				{
				doorClose = true;
				gateOpen2 = true;
				gateInCloseSign = false;
				gateOutCloseSign = true;
				}
				}
				if ( InTimer.Value =< OutTimer.Value)
				{
				if ( doorInControl2 == true and doorOutControl2 == true)
				{
				doorClose = true;
				gateOpen2 = true;
				gateInCloseSign = true;
				gateOutCloseSign = false;
				}
				}
				doorCloseSign = true;
				if (imputControl2 == true and outputControl2 == false)
				{
				gateControl2 = 1;
				}
				else if (imputControl2 == false and outputControl2 == true )
				{
				gateControl2 = 2;
				}
				else if (imputControl2 == false and outputControl2 == false and doorInControl2 == false and doorOutControl2 == false )
				{
				gateControl2 = 0;
				}
				else if (imputControl2 == false and outputControl2 == false and ( doorInControl2 == true or doorOutControl2 == true ))
				{
				gateControl2 = 4;
				}
				break;
				case 4:
				gateOpen2 = false;
				doorClose = false;
				gateInCloseSign = true;
				gateOutCloseSign = true;
				doorCloseSign = false;
				if (imputControl2 == true and outputControl2 == false)
				{
				gateControl2 = 1;
				}
				else if (imputControl2 == false and outputControl2 == true )
				{
				gateControl2 = 2;
				}
				else if (imputControl2 == true and outputControl2 == true )
				{
				gateControl2 = 3;
				}
				else if (imputControl2 == false and outputControl2 == false and doorInControl2 == false and doorOutControl2 == false )
				{
				gateControl2 = 0;
				}
				break;
				}
			 /*
			  * 
			  * 
			  * 
			  * Данный код педоставлен в ознакомительных целях, для конкетного внедрения на определенной системе удет нужна доработка под потребноси этой системы.
			  * This code is provided in acquittal purposes, for a particular implementation on a certain system, refinement will be needed for the need of this system.
			  * 
			  * 
			  * 
			  * */
		}
		public static void DisplayTimeEvent( object source, ElapsedEventArgs e )
		{
			isDone = true;
		}

	}
}